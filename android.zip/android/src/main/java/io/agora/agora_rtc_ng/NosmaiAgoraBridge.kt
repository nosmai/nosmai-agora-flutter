package io.agora.agora_rtc_ng

import android.content.Context
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.video.AgoraVideoFrame
import io.agora.rtc2.video.VideoEncoderConfiguration
import android.view.Surface
import android.app.Activity
import android.opengl.GLSurfaceView
import android.util.Log
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlin.math.min

// Nosmai SDK (AAR must be added to the app)
import com.example.example.api.NosmaiSDK
import com.example.example.api.NosmaiOffscreenSDK
import com.example.example.api.NosmaiPreviewView

object NosmaiAgoraBridge {
    // Singleton Agora instance - shared between Flutter and Native
    private var rtcEngine: RtcEngine? = null
    private var testFrameGenerator: TestFrameGenerator? = null
    private var camera2Handler: Camera2Handler? = null
    private var isCustomCameraActive = false
    private var channelJoined = false
    private var currentChannelId: String? = null
    private var currentUserId: Int = 0
    private var isInitialized = false
    private var previewSurface: Surface? = null
    // Nosmai state
    private var nosmaiInitialized = false
    private var nosmaiPreviewView: NosmaiPreviewView? = null
    private var nosmaiFrameCount = 0
    private var glSurfaceView: GLSurfaceView? = null
    private var renderer: NosmaiAgoraRenderer? = null
    private var yuvRenderer: YuvPreviewRenderer? = null
    private var glContainer: FrameLayout? = null
    @Volatile private var allowPush: Boolean = false
    private var nosmaiNativeCameraView: NosmaiPreviewView? = null
    private var nativeCameraHelper: Camera2Handler? = null
    private var cameraActivity: Activity? = null
    
    fun getEngine(): RtcEngine? {
        return rtcEngine
    }
    
    fun setActivity(activity: Activity?) {
        cameraActivity = activity
    }

    // Store license key for later use
    private var storedLicenseKey: String? = null
    
    fun initNosmai(context: Context, licenseKey: String): Boolean {
        return try {
            if (nosmaiInitialized) return true
    
            // Store license key for camera use
            storedLicenseKey = licenseKey
            
            // Initialize NosmaiOffscreenSDK for streaming
            NosmaiOffscreenSDK.setLicenseKey(licenseKey)
            NosmaiOffscreenSDK.initialize(context, object : NosmaiOffscreenSDK.OffscreenEventListener {
                override fun onInitialized() {
                    android.util.Log.i("NosmaiAgora", "NosmaiOffscreenSDK initialized successfully")
                    
                    // Also initialize regular NosmaiSDK for camera support
                    try {
                        // Use context directly for activity reference
                        if (context is Activity) {
                            NosmaiSDK.initialize(context, licenseKey)
                            android.util.Log.i("NosmaiAgora", "NosmaiSDK initialized with Activity context")
                        } else {
                            // If not activity, we might need to get the activity differently
                            NosmaiSDK.initialize(context, licenseKey)
                            android.util.Log.i("NosmaiAgora", "NosmaiSDK initialized with Application context")
                        }
                    } catch (e: Exception) {
                        android.util.Log.w("NosmaiAgora", "NosmaiSDK initialization warning: ${e.message}")
                    }
                    
                    nosmaiInitialized = true
                    try { NosmaiOffscreenSDK.setMirrorX(false) } catch (_: Throwable) {}
                }
                
                override fun onError(error: String) {
                    android.util.Log.e("NosmaiAgora", "NosmaiOffscreenSDK error: $error")
                }
            })
            
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to initialize Nosmai: ${e.message}")
            false
        }
    }
    
    fun setupYuvPreview(containerView: FrameLayout): Boolean {
        try {
            if (glSurfaceView != null) {
                // Re-attach existing GL view to the new container (PlatformView recreated)
                try {
                    val parent = glSurfaceView?.parent as? ViewGroup
                    parent?.removeView(glSurfaceView)
                } catch (_: Throwable) {}

                // Ensure container is clean and attach
                try { containerView.removeAllViews() } catch (_: Throwable) {}
                containerView.addView(glSurfaceView, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))
                return true
            }
            
            // Create new GLSurfaceView
            glSurfaceView = GLSurfaceView(containerView.context).apply {
                setEGLContextClientVersion(2)
                setEGLConfigChooser(8, 8, 8, 8, 16, 0)
                
                // Create YUV renderer for processed local preview
                yuvRenderer = YuvPreviewRenderer()
                setRenderer(yuvRenderer)
                renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            }
            
            // Add GLSurfaceView to container
            containerView.addView(glSurfaceView, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))

            return true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to setup GL view: ${e.message}")
            return false
        }
    }

    private fun ensureGLRenderer(activity: Activity) {
        if (glSurfaceView != null) return
        val root = activity.findViewById<ViewGroup>(android.R.id.content)
        val container = FrameLayout(activity)
        container.alpha = 0f
        container.isClickable = false
        container.isFocusable = false
        root.addView(
            container,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        glContainer = container
        setupYuvPreview(container)
    }
    
        

    // Initialize singleton Agora instance - called from Flutter on app start
    fun initAgora(context: Context, appId: String): Boolean {
        // Always release existing engine to ensure clean state for each stream session
        if (rtcEngine != null) {
            android.util.Log.d("NosmaiAgora", "Releasing existing engine for clean restart")
            try {
                rtcEngine?.leaveChannel()
                RtcEngine.destroy()
            } catch (e: Exception) {
                android.util.Log.e("NosmaiAgora", "Error releasing engine: ${e.message}")
            }
            rtcEngine = null
            isInitialized = false
            channelJoined = false
            currentChannelId = null
            currentUserId = 0
            allowPush = false
        }

        return try {
            val config = RtcEngineConfig()
            config.mContext = context.applicationContext
            config.mAppId = appId

            config.mEventHandler = object : IRtcEngineEventHandler() {
                override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
                    android.util.Log.e("NosmaiAgora", "JOIN_SUCCESS: Native joined channel: $channel, uid=$uid")
                    android.util.Log.i("NosmaiAgora", "SUCCESS: Native Agora in channel with UID=$uid")
                    android.util.Log.e("NosmaiAgora", "JOINED: Native user $uid is now in channel $channel")
                    println("NOSMAI: Successfully joined channel $channel with UID $uid")
                    channelJoined = true
                    currentChannelId = channel
                    currentUserId = uid
                    allowPush = true
                    
                    // Camera will be started by delayed initialization in startCustomCamera
                    // Don't start it here to avoid double initialization
                    android.util.Log.d("NosmaiAgora", "Join successful, camera will be initialized by delayed handler")
                }

                override fun onUserJoined(uid: Int, elapsed: Int) {
                    android.util.Log.e("NosmaiAgora", "USER_JOINED: Remote user joined: $uid")
                }
                
                override fun onLeaveChannel(stats: io.agora.rtc2.IRtcEngineEventHandler.RtcStats?) {
                    android.util.Log.e("NosmaiAgora", "LEFT_CHANNEL: Native left channel")
                    channelJoined = false
                    allowPush = false
                }

                override fun onUserOffline(uid: Int, reason: Int) {
                    android.util.Log.e("NosmaiAgora", "USER_OFFLINE: User left: $uid, reason=$reason")
                }
                
                override fun onError(err: Int) {
                    android.util.Log.e("NosmaiAgora", "AGORA_ERROR: Error code $err")
                    when(err) {
                        3 -> android.util.Log.e("NosmaiAgora", "ERROR: Failed to open channel (token expired or invalid)")
                        17 -> android.util.Log.e("NosmaiAgora", "ERROR: Failed to join channel (rejected by server)")
                        else -> android.util.Log.e("NosmaiAgora", "ERROR: Check Agora error code documentation")
                    }
                }
            }

            rtcEngine = RtcEngine.create(config)
            isInitialized = true
            android.util.Log.d("NosmaiAgora", "Singleton Agora instance created")
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to init: ${e.message}")
            false
        }
    }

    fun releaseAgora() {
        rtcEngine?.let {
            RtcEngine.destroy()
            rtcEngine = null
        }
    }
    
    fun getFlutterEngineInfo(): String {
        return try {
            val info = StringBuilder()
            
            // Check our native engine
            if (rtcEngine != null) {
                info.append("Native Engine: Active\n")
                info.append("Channel Joined: $channelJoined\n")
                info.append("Channel ID: $currentChannelId\n")
                info.append("User ID: $currentUserId\n")
            } else {
                info.append("Native Engine: Not initialized\n")
            }
            
            info.toString()
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }
    
    // Methods for Flutter to control native instance
    fun enableVideo(): Boolean {
        return try {
            rtcEngine?.enableVideo()
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to enable video: ${e.message}")
            false
        }
    }
    
    private var appContext: Context? = null
    
    fun enableLocalVideo(enabled: Boolean): Boolean {
        return try {
            rtcEngine?.enableLocalVideo(enabled) ?: -1
            
            // If enabling video and camera handler is not initialized, initialize it now
            if (enabled && isCustomCameraActive && camera2Handler == null) {
                android.util.Log.d("NosmaiAgora", "Initializing camera on enableLocalVideo")
                val context = appContext ?: return false
                
                camera2Handler = Camera2Handler(context)
                previewSurface?.let { 
                    camera2Handler?.setPreviewSurface(it) 
                }
                camera2Handler?.startCamera()
                android.util.Log.d("NosmaiAgora", "Camera started on enableLocalVideo")
            } else if (!enabled && camera2Handler != null) {
                // If disabling video, stop the camera
                android.util.Log.d("NosmaiAgora", "Stopping camera on disableLocalVideo")
                camera2Handler?.stopCamera()
                camera2Handler = null
            }
            
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to enable local video: ${e.message}")
            false
        }
    }
    
    fun startPreview(): Boolean {
        return try {
            rtcEngine?.startPreview()
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to start preview: ${e.message}")
            false
        }
    }
    
    fun stopPreview(): Boolean {
        return try {
            rtcEngine?.stopPreview()
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to stop preview: ${e.message}")
            false
        }
    }
    
    fun setClientRole(role: Int): Boolean {
        return try {
            rtcEngine?.setClientRole(role)
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to set client role: ${e.message}")
            false
        }
    }
    
    fun joinChannel(token: String, channelId: String, userId: Int): Boolean {
        return try {
            if (channelJoined && currentChannelId == channelId) {
                android.util.Log.d("NosmaiAgora", "Already in channel: $channelId")
                return true
            }
            
            rtcEngine?.joinChannel(token, channelId, "", userId)
            android.util.Log.d("NosmaiAgora", "Joining channel: $channelId with UID: $userId")
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to join channel: ${e.message}")
            false
        }
    }
    
    fun leaveChannel(): Boolean {
        return try {
            rtcEngine?.leaveChannel()
            channelJoined = false
            allowPush = false
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to leave channel: ${e.message}")
            false
        }
    }

    // Handler for delayed camera init
    private var cameraInitHandler: android.os.Handler? = null
    private var cameraInitRunnable: Runnable? = null
    
    // Beauty filters instance
    private val beautyFilters = BeautyFilters()
    
    // Apply brightness filter
    fun applyBrightness(brightness: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying brightness: $brightness")
        return beautyFilters.applyBrightness(brightness)
    }

    // Skin smoothing filter
    fun applySkinSmoothing(level: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying skin smoothing: $level")
        return beautyFilters.applySkinSmoothing(level)
    }

    // Skin whitening filter
    fun applySkinWhitening(level: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying skin whitening: $level")
        return beautyFilters.applySkinWhitening(level)
    }

    // Face slimming filter
    fun applyFaceSlimming(level: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying face slimming: $level")
        return beautyFilters.applyFaceSlimming(level)
    }

    // Eye enlargement filter
    fun applyEyeEnlargement(level: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying eye enlargement: $level")
        return beautyFilters.applyEyeEnlargement(level)
    }

    // Nose size filter
    fun applyNoseSize(level: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying nose size: $level")
        return beautyFilters.applyNoseSize(level)
    }

    // Contrast filter
    fun applyContrast(contrast: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying contrast: $contrast")
        return beautyFilters.applyContrast(contrast)
    }

    // Hue filter
    fun applyHue(hue: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying hue: $hue")
        return beautyFilters.applyHue(hue)
    }

    // RGB filter
    fun applyRGB(red: Float, green: Float, blue: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying RGB: R=$red, G=$green, B=$blue")
        return beautyFilters.applyRGB(red, green, blue)
    }

    // Lipstick makeup
    fun applyLipstick(intensity: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying lipstick: $intensity")
        return beautyFilters.applyLipstick(intensity)
    }

    // Blusher makeup
    fun applyBlusher(intensity: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying blusher: $intensity")
        return beautyFilters.applyBlusher(intensity)
    }

    // Remove all filters
    fun removeAllFilters(): Boolean {
        android.util.Log.d("NosmaiAgora", "Removing all filters")
        return beautyFilters.removeAllFilters()
    }

    // Get current filter states
    fun getCurrentFilterStates(): Map<String, Float> {
        return beautyFilters.getCurrentFilterStates()
    }

    // Check if any filter is active
    fun hasActiveFilters(): Boolean {
        return beautyFilters.hasActiveFilters()
    }

    // Apply makeup blend level
    fun applyMakeupBlendLevel(filterName: String, level: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying makeup blend level: $filterName = $level")
        return beautyFilters.applyMakeupBlendLevel(filterName, level)
    }

    // Exposure filter
    fun applyExposure(exposure: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying exposure: $exposure")
        return beautyFilters.applyExposure(exposure)
    }

    // Saturation filter
    fun applySaturation(saturation: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying saturation: $saturation")
        return beautyFilters.applySaturation(saturation)
    }

    // Sharpen filter
    fun applySharpen(sharpen: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying sharpen: $sharpen")
        return beautyFilters.applySharpen(sharpen)
    }

    // White balance filter
    fun applyWhiteBalance(temperatureK: Float, tint: Float): Boolean {
        android.util.Log.d("NosmaiAgora", "Applying white balance: temp=$temperatureK, tint=$tint")
        return beautyFilters.applyWhiteBalance(temperatureK, tint)
    }

    // Grayscale filter
    fun setGrayscaleEnabled(enabled: Boolean): Boolean {
        android.util.Log.d("NosmaiAgora", "Setting grayscale: $enabled")
        return beautyFilters.setGrayscaleEnabled(enabled)
    }
    
    // Teardown all streaming resources safely (idempotent)
    fun teardownStreaming() {
        android.util.Log.d("NosmaiAgora", "teardownStreaming called")
        
        // Cancel any pending camera initialization
        cameraInitRunnable?.let { 
            cameraInitHandler?.removeCallbacks(it)
            cameraInitRunnable = null
        }
        
        // First stop frame pushing
        try { allowPush = false } catch (_: Throwable) {}
        try { channelJoined = false } catch (_: Throwable) {}
        
        // Stop camera and clear handler
        try { 
            camera2Handler?.stopCamera()
            camera2Handler = null
            // Add delay to ensure camera is fully released
            Thread.sleep(200)
        } catch (e: Throwable) {
            android.util.Log.e("NosmaiAgora", "Error stopping camera: ${e.message}")
        }
        
        // Clear frame listener and cleanup Nosmai SDK (but don't destroy it)
        try { 
            NosmaiOffscreenSDK.setFrameListener(null)
            // Don't call cleanup() here - keep SDK initialized for reuse
            // NosmaiOffscreenSDK.cleanup() 
        } catch (e: Throwable) {
            android.util.Log.e("NosmaiAgora", "Error clearing frame listener: ${e.message}")
        }
        
        // Disable external video source in Agora
        try {
            rtcEngine?.setExternalVideoSource(
                false,
                false,
                io.agora.rtc2.Constants.ExternalVideoSourceType.VIDEO_FRAME
            )
        } catch (e: Throwable) {
            android.util.Log.e("NosmaiAgora", "Error disabling external video: ${e.message}")
        }
        
        // Leave channel and destroy engine to ensure clean state
        try { 
            rtcEngine?.leaveChannel()
            // Add delay to ensure channel leave completes
            Thread.sleep(200)
            
            // Destroy the engine completely to avoid SIGSEGV on next use
            RtcEngine.destroy()
            rtcEngine = null
            isInitialized = false
        } catch (e: Throwable) {
            android.util.Log.e("NosmaiAgora", "Error leaving channel/destroying engine: ${e.message}")
        }
        
        // Clear state variables
        currentChannelId = null
        currentUserId = 0
        isCustomCameraActive = false
        
        android.util.Log.d("NosmaiAgora", "teardownStreaming completed - engine destroyed")
    }
    
    fun startCustomCamera(context: Context, appId: String, token: String, channelId: String, userId: Int = 0, startCameraImmediately: Boolean = true): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "startCustomCamera called - channelId: $channelId, userId: $userId, startCameraImmediately: $startCameraImmediately")
            
            // Store context for later use
            appContext = context.applicationContext
            
            // For multi-host scenario: if same channel but different user, need to restart camera
            if (isCustomCameraActive && currentChannelId == channelId) {
                if (currentUserId != userId && userId != 0) {
                    android.util.Log.d("NosmaiAgora", "Same channel but different user (multi-host) - restarting camera for user: $userId")
                    // Stop current camera and restart for new host
                    camera2Handler?.stopCamera()
                    camera2Handler = null
                    Thread.sleep(200) // Small delay to ensure camera is released
                    // Continue to setup camera for new host
                } else {
                    android.util.Log.d("NosmaiAgora", "Already active for same channel and user")
                    return true
                }
            }
            
            // If active with different channel, cleanup first
            if (isCustomCameraActive && currentChannelId != channelId) {
                android.util.Log.d("NosmaiAgora", "Switching channels - cleaning up first")
                teardownStreaming()
                // Add small delay to ensure cleanup completes
                Thread.sleep(100)
            }
            
            // Ensure singleton is initialized
            if (!isInitialized || rtcEngine == null) {
                android.util.Log.e("NosmaiAgora", "Initializing Agora engine")
                if (!initAgora(context, appId)) {
                    android.util.Log.e("NosmaiAgora", "Failed to initialize Agora")
                    return false
                }
            }
            
            android.util.Log.e("NosmaiAgora", "Configuring video settings")
            
            // Configure video (CPU path with RGBA->I420)
            rtcEngine?.enableVideo()
            rtcEngine?.setClientRole(io.agora.rtc2.Constants.CLIENT_ROLE_BROADCASTER)
            rtcEngine?.adjustPlaybackSignalVolume(0)
            rtcEngine?.muteAllRemoteAudioStreams(true)
            android.util.Log.d("NosmaiAgora", "Disabled audio playback for broadcaster to prevent echo")
            // Enable audio for broadcasting
            rtcEngine?.enableAudio()
            
            // Mute all remote audio streams to prevent hearing other participants
            // This only affects local playback, not publishing
            rtcEngine?.muteAllRemoteAudioStreams(true)
            android.util.Log.d("NosmaiAgora", "Enabled audio publishing, muted remote audio playback")
            
            renderer?.setCallInProgress(false)
            
            

            // Set up external video source for test pattern
            val extSourceResult = rtcEngine?.setExternalVideoSource(
                true, // enable
                false, // useTexture = false (I420 push)
                io.agora.rtc2.Constants.ExternalVideoSourceType.VIDEO_FRAME
            )
            android.util.Log.e("NosmaiAgora", "External video source setup result: $extSourceResult")
            
            // Configure video encoder (720p portrait with rotation metadata)
            val videoConfig = io.agora.rtc2.video.VideoEncoderConfiguration()
            videoConfig.dimensions = io.agora.rtc2.video.VideoEncoderConfiguration.VideoDimensions(720, 1280)
            videoConfig.frameRate = 30
            videoConfig.bitrate = 1800
            val encConfigResult = rtcEngine?.setVideoEncoderConfiguration(videoConfig)
            android.util.Log.e("NosmaiAgora", "Video encoder config result: $encConfigResult")
            
            // Join channel with the SAME user ID to publish as the primary host
            val nativeUserId = userId
            
            android.util.Log.e("NosmaiAgora", "JOINING: channel=$channelId, nativeUserId=$nativeUserId, token=${token.take(20)}...")
            
            val joinResult = rtcEngine?.joinChannel(token, channelId, "", nativeUserId)
            android.util.Log.e("NosmaiAgora", "Join channel result: $joinResult")
            
            if (joinResult != 0) {
                android.util.Log.e("NosmaiAgora", "JOIN_FAILED: Error code $joinResult")
                when(joinResult) {
                    -2 -> android.util.Log.e("NosmaiAgora", "Invalid argument")
                    -3 -> android.util.Log.e("NosmaiAgora", "SDK not ready")
                    -5 -> android.util.Log.e("NosmaiAgora", "Call rejected")
                    -7 -> android.util.Log.e("NosmaiAgora", "SDK not initialized")
                    else -> android.util.Log.e("NosmaiAgora", "Unknown error")
                }
            }
            
            // Setup offscreen RGBA output for effects processing and preview
            try {
                // Request RGBA from offscreen for accurate preview and effects
                // Camera captures 1280x720 but we want portrait output
                NosmaiOffscreenSDK.setOffscreenRendering(720, 1280, NosmaiOffscreenSDK.PixelFormat.RGBA)
                NosmaiOffscreenSDK.setFrameListener { data, width, height, format, timestampNs ->
                    if (data == null) return@setFrameListener
                    
                    if (format.equals("RGBA", ignoreCase = true)) {
                        // Convert RGBA to I420 for Agora streaming
                        val i420 = rgbaToI420(data, width, height)
                        if (allowPush && channelJoined) {
                            pushFrameToNativeAgora(i420, width, height)
                        }
                        // For local preview, convert RGBA to YUV if using YuvRenderer
                        yuvRenderer?.submitFrame(i420, width, height)
                    } else if (format.equals("I420", ignoreCase = true)) {
                        // Fallback if we get I420
                        val corrected = i420SwapUV(data, width, height)
                        if (allowPush && channelJoined) {
                            pushFrameToNativeAgora(corrected, width, height)
                        }
                        yuvRenderer?.submitFrame(corrected, width, height)
                    }
                }
            } catch (t: Throwable) {
                android.util.Log.e("NosmaiAgora", "Failed to init offscreen listener: ${t.message}")
            }

            // Store channel info for later use
            currentChannelId = channelId
            currentUserId = userId
            isCustomCameraActive = true
            
            android.util.Log.d("NosmaiAgora", "Updated current state - channelId: $currentChannelId, userId: $currentUserId")
            
            // Initialize camera asynchronously to avoid blocking (only if startCameraImmediately is true)
            if (startCameraImmediately) {
                cameraInitHandler = android.os.Handler(android.os.Looper.getMainLooper())
                cameraInitRunnable = Runnable {
                    try {
                        // Check if still active (not torn down)
                        if (!isCustomCameraActive) {
                            android.util.Log.d("NosmaiAgora", "Camera init cancelled - stream no longer active")
                            return@Runnable
                        }
                        
                        // Check if camera already initialized (prevent double init)
                        if (camera2Handler != null) {
                            android.util.Log.d("NosmaiAgora", "Camera already initialized, skipping")
                            return@Runnable
                        }
                        
                        android.util.Log.d("NosmaiAgora", "Delayed camera initialization starting")
                        
                        // Ensure camera is stopped before starting streaming camera
                        if (isStandaloneCameraActive) {
                            android.util.Log.d("NosmaiAgora", "Stopping camera before starting streaming camera")
                            try {
                                NosmaiSDK.stopProcessing()
                                isStandaloneCameraActive = false
                                Thread.sleep(400) // Give extra time for camera resource to be fully released
                            } catch (e: Exception) {
                                android.util.Log.w("NosmaiAgora", "Failed to stop camera: ${e.message}")
                            }
                        }
                        
                        // Start Camera2 to feed Nosmai offscreen
                        android.util.Log.d("NosmaiAgora", "Creating new Camera2Handler")
                        camera2Handler = Camera2Handler(context)
                        
                        // Set preview surface if available
                        previewSurface?.let { 
                            android.util.Log.d("NosmaiAgora", "Setting preview surface")
                            camera2Handler?.setPreviewSurface(it) 
                        }
                        
                        // CRITICAL: Set up frame callback to feed frames into NosmaiOffscreenSDK
                        camera2Handler?.setFrameCallback { i420Data: ByteArray, width: Int, height: Int ->
                            // This callback receives processed I420 frames from Camera2Handler and feeds them to Nosmai
                            android.util.Log.v("NosmaiAgora", "Received frame ${width}x${height}, size: ${i420Data.size}")
                            // The Camera2Handler already processes and rotates the frames, so we can feed them directly
                            // Note: The Camera2Handler's implementation already calls NosmaiOffscreenSDK.receiveFrame internally
                        }
                        
                        // Start camera
                        camera2Handler?.startCamera()
                        android.util.Log.d("NosmaiAgora", "Camera2 started for offscreen I420 feed")
                    
                    } catch (e: Exception) {
                        android.util.Log.e("NosmaiAgora", "Failed to start camera: ${e.message}")
                        e.printStackTrace()
                    }
                }
                cameraInitHandler?.postDelayed(cameraInitRunnable!!, 500) // 500ms delay to ensure everything is ready
            } else {
                android.util.Log.d("NosmaiAgora", "Camera initialization skipped - waiting for explicit enable")
            }
            
            android.util.Log.d("NosmaiAgora", "CUSTOM_CAMERA_STARTED: Setup complete, camera will start shortly")
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to start: ${e.message}")
            e.printStackTrace()
            false
        }
    }
    
    fun stopCustomCamera(): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "stopCustomCamera called")
            
            // Stop any test generator if running
            testFrameGenerator?.stop()
            testFrameGenerator = null
            
            // Stop Camera2 capture if not already stopped
            if (camera2Handler != null) {
                camera2Handler?.stopCamera()
                camera2Handler = null
            }
            
            renderer?.setCallInProgress(false)
            
            // Remove hidden GL container
            try {
                val cont = glContainer
                val gl = glSurfaceView
                if (cont != null) {
                    val parent = cont.parent as? ViewGroup
                    parent?.removeView(cont)
                }
                glSurfaceView = null
                glContainer = null
                renderer = null
            } catch (_: Throwable) {}

            // Leave channel if joined
            if (channelJoined) {
                rtcEngine?.leaveChannel()
                channelJoined = false
            }
            
            // Clear frame listener but don't destroy NosmaiSDK (keep for reuse)
            try {
                NosmaiOffscreenSDK.setFrameListener(null)
                // Don't call cleanup() - keep SDK initialized for reuse
                // NosmaiOffscreenSDK.cleanup()
            } catch (e: Exception) {
                android.util.Log.e("NosmaiAgora", "Error clearing frame listener: ${e.message}")
            }

            // Disable external video source
            rtcEngine?.setExternalVideoSource(
                false,
                false, 
                io.agora.rtc2.Constants.ExternalVideoSourceType.VIDEO_FRAME
            )
            
            // Reset state flags
            isCustomCameraActive = false
            allowPush = false
            currentChannelId = null
            currentUserId = 0
            
            android.util.Log.d("NosmaiAgora", "stopCustomCamera completed")
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to stop: ${e.message}")
            false
        }
    }

    // Called from PlatformView to attach preview surface for zero-latency preview
    fun setCameraPreviewSurface(surface: Surface?) {
        previewSurface = surface
        if (camera2Handler == null) {
            android.util.Log.w("NosmaiAgora", "setCameraPreviewSurface: camera2Handler is null (will attach when camera starts)")
            return
        }
        android.util.Log.d("NosmaiAgora", "Attaching preview surface now: ${surface != null}")
        camera2Handler?.attachPreviewSurface(surface)
    }
    
    private var frameCount = 0
    
    private fun pushFrameToNativeAgora(data: ByteArray, width: Int, height: Int) {
        try {
            rtcEngine?.let { engine ->
                val videoFrame = AgoraVideoFrame()
                videoFrame.format = AgoraVideoFrame.FORMAT_I420
                videoFrame.stride = width
                videoFrame.height = height
                videoFrame.buf = data
                videoFrame.timeStamp = System.currentTimeMillis()
                // No rotation needed - Nosmai now correctly rotates based on sensor orientation
                videoFrame.rotation = 0
                
                val result = engine.pushExternalVideoFrame(videoFrame)
                
                frameCount++
                if (frameCount % 10 == 0) {
                    android.util.Log.d("NosmaiAgora", "Pushed frame #$frameCount to Agora")
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Error pushing: ${e.message}")
        }
    }

    // RGBA -> I420 conversion (planar YUV) for offscreen RGBA output
    private fun rgbaToI420(rgba: ByteArray, width: Int, height: Int): ByteArray {
        val ySize = width * height
        val uvSize = ySize / 4
        val out = ByteArray(ySize + uvSize * 2)
        var yIndex = 0
        var uIndex = ySize
        var vIndex = ySize + uvSize

        var idx = 0
        // Luma
        for (j in 0 until height) {
            for (i in 0 until width) {
                val r = rgba[idx].toInt() and 0xFF
                val g = rgba[idx + 1].toInt() and 0xFF
                val b = rgba[idx + 2].toInt() and 0xFF
                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                out[yIndex++] = y.coerceIn(0, 255).toByte()
                idx += 4 // skip alpha
            }
        }

        // Chroma subsampling 4:2:0
        for (j in 0 until height step 2) {
            for (i in 0 until width step 2) {
                val p1 = (j * width + i) * 4
                val p2 = (j * width + i + 1) * 4
                val p3 = ((j + 1) * width + i) * 4
                val p4 = ((j + 1) * width + i + 1) * 4

                val r = ((rgba[p1].toInt() and 0xFF) + (rgba[p2].toInt() and 0xFF) +
                         (rgba[p3].toInt() and 0xFF) + (rgba[p4].toInt() and 0xFF)) / 4
                val g = ((rgba[p1 + 1].toInt() and 0xFF) + (rgba[p2 + 1].toInt() and 0xFF) +
                         (rgba[p3 + 1].toInt() and 0xFF) + (rgba[p4 + 1].toInt() and 0xFF)) / 4
                val b = ((rgba[p1 + 2].toInt() and 0xFF) + (rgba[p2 + 2].toInt() and 0xFF) +
                         (rgba[p3 + 2].toInt() and 0xFF) + (rgba[p4 + 2].toInt() and 0xFF)) / 4

                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                out[uIndex++] = u.coerceIn(0, 255).toByte()
                out[vIndex++] = v.coerceIn(0, 255).toByte()
            }
        }
        return out
    }

    // Swap U and V planes in an I420 buffer (to handle YV12 output)
    private fun i420SwapUV(src: ByteArray, width: Int, height: Int): ByteArray {
        val ySize = width * height
        val uvSize = ySize / 4
        // src: [Y][U][V] => dst: [Y][V][U]
        val dst = ByteArray(src.size)
        System.arraycopy(src, 0, dst, 0, ySize)
        // swap chroma planes
        System.arraycopy(src, ySize + uvSize, dst, ySize, uvSize) // V -> U
        System.arraycopy(src, ySize, dst, ySize + uvSize, uvSize) // U -> V
        return dst
    }
    fun clearGLResources() {
        renderer?.setCallInProgress(false)
        glSurfaceView = null
        renderer = null
    }

    // Start native camera for Nosmai preview
    fun startNativeCameraForPreview(previewView: NosmaiPreviewView): Boolean {
        return try {
            if (!nosmaiInitialized) {
                android.util.Log.e("NosmaiAgora", "Nosmai SDK not initialized")
                return false
            }

            // For now, just store the reference
            // The NosmaiPreviewView handles its own camera internally
            nosmaiNativeCameraView = previewView
            
            // Set mirror for front camera
            try { 
                NosmaiSDK.setCameraFacing(true) // Start with front camera
                NosmaiSDK.setMirrorX(true)
            } catch (_: Throwable) {}
            
            android.util.Log.i("NosmaiAgora", "Native camera preview ready")
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to start native camera: ${e.message}")
            false
        }
    }
    
    // Stop native camera for preview
    fun stopNativeCameraForPreview(): Boolean {
        return try {
            nativeCameraHelper?.stopCamera()
            nativeCameraHelper = null
            nosmaiNativeCameraView = null
            
            android.util.Log.i("NosmaiAgora", "Native camera stopped")
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to stop native camera: ${e.message}")
            false
        }
    }
    
    private fun calculateFrameRotation(sensorOrientation: Int, front: Boolean): Int {
        return if (front) { 
            if (sensorOrientation == 270) 1 else 6 
        } else { 
            if (sensorOrientation == 90) 2 else 1 
        }
    }
    
    // Camera Support - No streaming required
    private var isStandaloneCameraActive = false
    private var isFrontCamera = true
    private var nativeCameraView: Any? = null // Reference to NosmaiNativeCameraView
    
    fun startCameraPreview(context: Context): Boolean {
        return try {
            if (!nosmaiInitialized) {
                android.util.Log.e("NosmaiAgora", "Nosmai SDK not initialized for camera")
                return false
            }
            
            if (isStandaloneCameraActive) {
                android.util.Log.d("NosmaiAgora", "Camera already active")
                return true
            }
            
            // Stop any existing streaming camera to prevent conflicts
            try {
                camera2Handler?.stopCamera()
                android.util.Log.d("NosmaiAgora", "Stopped streaming camera to avoid conflicts")
            } catch (e: Exception) {
                android.util.Log.w("NosmaiAgora", "Failed to stop streaming camera: ${e.message}")
            }
            
            // Add a small delay to ensure camera is fully released
            Thread.sleep(300)
            
            // Ensure we have a preview view for camera (like reference implementation)
            if (appContext != null && previewSurface == null) {
                // Create hidden preview view for GL context (like reference line 287)
                try {
                    val activity = appContext as? Activity
                    if (activity != null) {
                        val previewView = NosmaiPreviewView(activity)
                        val root = activity.findViewById<ViewGroup>(android.R.id.content)
                        if (previewView.parent == null) {
                            val lp = ViewGroup.LayoutParams(1, 1)
                            root.addView(previewView, lp)
                            previewView.alpha = 0f
                        }
                        
                        // CRITICAL: Initialize pipeline to set GLView for beauty filters (reference line 299)
                        try {
                            previewView.initializePipeline()
                            android.util.Log.i("NosmaiAgora", "✅ Pipeline initialized - GLView set for beauty filters in camera")
                        } catch (e: Exception) {
                            android.util.Log.w("NosmaiAgora", "⚠️ Pipeline initialization warning: ${e.message}")
                        }
                        
                        // Start processing with preview view (reference line 444)
                        try {
                            NosmaiSDK.startProcessing(previewView)
                            android.util.Log.d("NosmaiAgora", "Started NosmaiSDK processing with preview view for camera")
                        } catch (e: Exception) {
                            android.util.Log.e("NosmaiAgora", "Failed to start NosmaiSDK processing: ${e.message}")
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.e("NosmaiAgora", "Failed to create preview view for camera: ${e.message}")
                }
            }
            
            // Configure camera settings for use
            NosmaiSDK.setCameraFacing(isFrontCamera)
            NosmaiSDK.setMirrorX(isFrontCamera)
            
            isStandaloneCameraActive = true
            android.util.Log.i("NosmaiAgora", "Camera preview started with pipeline initialized")
            
            // Update camera capabilities
            
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to start Camera: ${e.message}")
            false
        }
    }
    
    
    fun stopCameraPreview(): Boolean {
        return try {
            if (!isStandaloneCameraActive) {
                android.util.Log.d("NosmaiAgora", "Camera not active")
                return true
            }
            
            // Stop Nosmai SDK processing (reference line 466)
            try {
                NosmaiSDK.stopProcessing()
                android.util.Log.d("NosmaiAgora", "Stopped NosmaiSDK processing for camera")
            } catch (_: Throwable) {}
            
            // Clear mirror and camera settings to reset state for streaming
            try {
                NosmaiSDK.setMirrorX(false) // Reset to streaming default
            } catch (_: Throwable) {}
            
            // Clean up preview view - don't destroy it, keep for reuse
            // PreviewView = null
            
            isStandaloneCameraActive = false
            android.util.Log.i("NosmaiAgora", "Camera preview stopped and reset for streaming")
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to stop camera: ${e.message}")
            false
        }
    }
    
    fun switchCamera(): Boolean {
        return try {
            if (!isStandaloneCameraActive) {
                android.util.Log.e("NosmaiAgora", "Camera not active")
                return false
            }
            
            isFrontCamera = !isFrontCamera
            NosmaiSDK.setCameraFacing(isFrontCamera)
            NosmaiSDK.setMirrorX(isFrontCamera)
            
            android.util.Log.d("NosmaiAgora", "Camera switched to ${if (isFrontCamera) "front" else "back"}")
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to switch camera: ${e.message}")
            false
        }
    }
    
    
    fun setFlashMode(flashMode: String): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Flash mode: $flashMode")
            // Flash control would be implemented via Camera2 API
            // For now, return true as placeholder
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to set flash mode: ${e.message}")
            false
        }
    }
    
    fun setTorchMode(torchMode: String): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Torch mode: $torchMode")
            // Torch control would be implemented via Camera2 API
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to set torch mode: ${e.message}")
            false
        }
    }

    // Cleanup resources
    fun cleanup(): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Cleaning up resources")
            // Cleanup Nosmai SDK, Camera2, and other resources
            // releaseNosmai()
            releaseAgora()
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to cleanup: ${e.message}")
            false
        }
    }

    // Recording Methods
    fun startRecording(): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Starting recording")
            // Recording would be implemented via Nosmai SDK
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to start recording: ${e.message}")
            false
        }
    }

    fun stopRecording(): Map<String, Any> {
        return try {
            android.util.Log.d("NosmaiAgora", "Stopping recording")
            // Recording would be stopped via Nosmai SDK
            mapOf(
                "success" to true,
                "videoPath" to "/path/to/recorded/video.mp4",
                "duration" to 10.0,
                "fileSize" to 1024000
            )
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to stop recording: ${e.message}")
            mapOf(
                "success" to false,
                "error" to (e.message ?: "Recording failed")
            )
        }
    }

    // Photo Capture
    fun capturePhoto(): Map<String, Any> {
        return try {
            android.util.Log.d("NosmaiAgora", "Capturing photo")
            // Photo capture would be implemented via Camera2 API
            mapOf(
                "success" to true,
                "photoPath" to "/path/to/captured/photo.jpg",
                "width" to 1920,
                "height" to 1080
            )
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to capture photo: ${e.message}")
            mapOf(
                "success" to false,
                "error" to (e.message ?: "Photo capture failed")
            )
        }
    }

    // Gallery Save Methods
    fun saveImageToGallery(imageData: ByteArray, name: String): Map<String, Any> {
        return try {
            android.util.Log.d("NosmaiAgora", "Saving image to gallery: $name")
            // Save image to device gallery
            mapOf(
                "success" to true,
                "path" to "/path/to/saved/image.jpg"
            )
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to save image: ${e.message}")
            mapOf(
                "success" to false,
                "error" to (e.message ?: "Image save failed")
            )
        }
    }

    fun saveVideoToGallery(videoPath: String, name: String): Map<String, Any> {
        return try {
            android.util.Log.d("NosmaiAgora", "Saving video to gallery: $name")
            // Save video to device gallery
            mapOf(
                "success" to true,
                "path" to videoPath
            )
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to save video: ${e.message}")
            mapOf(
                "success" to false,
                "error" to (e.message ?: "Video save failed")
            )
        }
    }

    // HSB Adjustment Methods
    fun adjustHSB(hue: Double, saturation: Double, brightness: Double): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Adjusting HSB: H=$hue, S=$saturation, B=$brightness")
            // HSB adjustment would be implemented via Nosmai SDK
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to adjust HSB: ${e.message}")
            false
        }
    }

    fun resetHSBFilter(): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Resetting HSB filter")
            // Reset HSB filter via Nosmai SDK
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to reset HSB filter: ${e.message}")
            false
        }
    }

    // Beauty Filter Status
    fun isBeautyFilterEnabled(): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Checking beauty filter status")
            // Check beauty filter status via Nosmai SDK
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to check beauty filter status: ${e.message}")
            false
        }
    }

    // Flash/Torch Capability Methods
    fun hasFlash(): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Checking flash capability")
            // Check flash capability via Camera2 API
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to check flash capability: ${e.message}")
            false
        }
    }

    fun hasTorch(): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Checking torch capability")
            // Check torch capability via Camera2 API
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to check torch capability: ${e.message}")
            false
        }
    }

    fun getFlashMode(): String {
        return try {
            android.util.Log.d("NosmaiAgora", "Getting flash mode")
            // Get current flash mode
            "off"
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to get flash mode: ${e.message}")
            "off"
        }
    }

    fun getTorchMode(): String {
        return try {
            android.util.Log.d("NosmaiAgora", "Getting torch mode")
            // Get current torch mode
            "off"
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to get torch mode: ${e.message}")
            "off"
        }
    }

    // Camera Configuration
    fun configureCamera(position: String, sessionPreset: String): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Configuring camera: position=$position, preset=$sessionPreset")
            // Configure camera position and session preset
            val isFront = position.equals("front", ignoreCase = true)
            NosmaiSDK.setCameraFacing(isFront)
            if (isFront) {
                NosmaiSDK.setMirrorX(true)
            }
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to configure camera: ${e.message}")
            false
        }
    }

    // Reinitialize Camera Preview
    fun reinitializePreview(): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Reinitializing camera preview")
            // Stop current preview and restart with current settings
            if (isStandaloneCameraActive) {
                stopCameraPreview()
                Thread.sleep(100) // Small delay
                startCameraPreview(cameraActivity ?: return false)
            }
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to reinitialize preview: ${e.message}")
            false
        }
    }

    // Detach Camera View
    fun detachCameraView(): Boolean {
        return try {
            android.util.Log.d("NosmaiAgora", "Detaching camera view")
            // Detach camera view without stopping the camera entirely
            nosmaiNativeCameraView = null
            nativeCameraView = null
            true
        } catch (e: Exception) {
            android.util.Log.e("NosmaiAgora", "Failed to detach camera view: ${e.message}")
            false
        }
    }
}