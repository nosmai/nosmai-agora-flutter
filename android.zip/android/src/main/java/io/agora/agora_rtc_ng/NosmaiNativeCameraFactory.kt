package io.agora.agora_rtc_ng

import android.content.Context
import android.widget.FrameLayout
import com.example.example.api.NosmaiPreviewView
import com.example.example.api.NosmaiSDK
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory
import android.util.Log
import java.nio.ByteBuffer

class NosmaiNativeCameraFactory : PlatformViewFactory(StandardMessageCodec.INSTANCE) {
    override fun create(context: Context, viewId: Int, args: Any?): PlatformView {
        return NosmaiNativeCameraView(context)
    }
}

class NosmaiNativeCameraView(private val context: Context) : PlatformView {
    private val container = FrameLayout(context)
    private var previewView: NosmaiPreviewView? = null
    private var camera2Handler: Camera2Handler? = null
    private var usingPlatformView: Boolean = true // Key flag from reference implementation

    init {
        try {
            // Create Nosmai preview view (like reference implementation line 96)
            previewView = NosmaiPreviewView(context)
            
            // Add to container
            container.addView(
                previewView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            
            // CRITICAL: Initialize pipeline to set GLView for rendering (like reference line 299)
            previewView?.initializePipeline()
            Log.i("NosmaiNativeCamera", "✅ Pipeline initialized - GLView set for rendering")
            
            // Start processing with the preview view (like reference line 444)
            NosmaiSDK.startProcessing(previewView!!)
            Log.i("NosmaiNativeCamera", "▶️ NosmaiSDK.startProcessing called")
            
            // Now start the camera capture to feed frames into the preview
            startCameraCapture()
            
            Log.i("NosmaiNativeCamera", "🚀 Processing and camera capture started")
        } catch (e: Exception) {
            Log.e("NosmaiNativeCamera", "Failed to initialize preview: ${e.message}")
        }
    }
    
    private fun startCameraCapture() {
        try {
            // Create Camera2Handler for frame capture (like reference implementation)
            camera2Handler = Camera2Handler(context)
            
            // Set up YUV frame callback exactly like reference implementation (lines 1750-1791)
            camera2Handler?.setFrameCallback { yBuffer: ByteBuffer, uBuffer: ByteBuffer, vBuffer: ByteBuffer, 
                width: Int, height: Int, yStride: Int, uStride: Int, vStride: Int, uPixelStride: Int, vPixelStride: Int ->
                
                if (yBuffer == null || uBuffer == null || vBuffer == null) return@setFrameCallback
                
                // Follow EXACT reference implementation pattern (line 1758)
                if (usingPlatformView) {
                    previewView?.let { pv ->
                        try {
                            // Calculate rotation like reference implementation
                            val handler = camera2Handler
                            val rotation = if (handler != null) {
                                calculateFrameRotation(handler.getSensorOrientation(), handler.isFrontCamera())
                            } else {
                                0
                            }
                            
                            // Render directly into preview view (reference lines 1760-1767)
                            pv.processYuvFrame(
                                yBuffer, uBuffer, vBuffer,
                                width, height,
                                yStride, uStride, vStride,
                                uPixelStride, vPixelStride,
                                rotation
                            )
                            pv.requestRenderUpdate()
                            return@setFrameCallback // Important: return here like reference line 1768
                        } catch (e: Exception) {
                            Log.e("NosmaiNativeCamera", "Error processing YUV frame: ${e.message}")
                        }
                    }
                }
            }
            
            // Start the camera capture
            camera2Handler?.startCamera()
            
            // Set camera orientation and mirroring after camera is started (when we have actual sensor orientation)
            camera2Handler?.let { handler ->
                val isFront = handler.isFrontCamera()
                val sensorOrientation = handler.getSensorOrientation()
                
                // Set camera orientation for the preview view
                previewView?.setCameraOrientation(isFront, sensorOrientation)
                
                // Set mirroring for front camera (like reference implementation)
                try {
                    NosmaiSDK.setMirrorX(isFront)
                    Log.i("NosmaiNativeCamera", "Mirror set to: $isFront")
                } catch (e: Exception) {
                    Log.w("NosmaiNativeCamera", "Failed to set mirror: ${e.message}")
                }
                
                Log.i("NosmaiNativeCamera", "Camera setup: front=$isFront, orientation=$sensorOrientation, mirrored=$isFront")
            }
            
            Log.i("NosmaiNativeCamera", "Camera2Handler started - frames should now feed into preview")
            
        } catch (e: Exception) {
            Log.e("NosmaiNativeCamera", "Failed to start camera capture: ${e.message}")
        }
    }
    
    // Calculate frame rotation based on sensor orientation and camera facing (from reference implementation)
    private fun calculateFrameRotation(sensorOrientation: Int, front: Boolean): Int {
        return if (front) { 
            if (sensorOrientation == 270) 1 else 6 
        } else { 
            if (sensorOrientation == 90) 2 else 1 
        }
    }

    override fun getView(): android.view.View = container

    override fun dispose() {
        try {
            Log.i("NosmaiNativeCamera", "Starting dispose - stopping camera and processing")
            
            // Stop camera capture first with immediate cleanup
            camera2Handler?.stopCamera()
            camera2Handler = null
            
            // Stop processing pipeline
            NosmaiSDK.stopProcessing()
            
            // Reset mirror setting for streaming (if it switches back)
            try {
                NosmaiSDK.setMirrorX(false) // Reset to streaming default
            } catch (_: Throwable) {}
            
            // Clean up view
            container.removeAllViews()
            previewView = null
            
            Log.i("NosmaiNativeCamera", "Preview and camera disposed, resources should be released for streaming")
        } catch (e: Exception) {
            Log.e("NosmaiNativeCamera", "Error disposing preview: ${e.message}")
        }
    }
}