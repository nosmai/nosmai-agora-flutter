package io.agora.agora_rtc_ng;

import android.content.Context;
import androidx.annotation.NonNull;
import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import com.example.example.NosmaiEffects;

/**
 * Plugin bridge for Nosmai Agora integration
 * Provides Flutter method channels for beauty filters and streaming
 * functionality
 */
public class NosmaiAgoraPlugin implements FlutterPlugin, MethodCallHandler {
    private static final String CHANNEL = "nosmai_agora";

    private MethodChannel channel;
    private Context context;

    @Override
    public void onAttachedToEngine(@NonNull FlutterPluginBinding flutterPluginBinding) {
        context = flutterPluginBinding.getApplicationContext();
        channel = new MethodChannel(flutterPluginBinding.getBinaryMessenger(), CHANNEL);
        channel.setMethodCallHandler(this);
    }

    @Override
    public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
        channel.setMethodCallHandler(null);
    }

    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull Result result) {
        try {
            switch (call.method) {
                // SDK Initialization
                case "initialize":
                    String licenseKey = call.argument("licenseKey");
                    boolean initResult = NosmaiAgoraBridge.INSTANCE.initNosmai(context, licenseKey);
                    result.success(initResult);
                    break;

                case "initAgora":
                    String appId = call.argument("appId");
                    boolean agoraInitResult = NosmaiAgoraBridge.INSTANCE.initAgora(context, appId);
                    result.success(agoraInitResult);
                    break;

                case "releaseAgora":
                    NosmaiAgoraBridge.INSTANCE.releaseAgora();
                    result.success(true);
                    break;

                // Streaming Control
                case "startCustomCamera":
                    String startAppId = call.argument("appId");
                    String token = call.argument("token");
                    String channelId = call.argument("channelId");
                    Integer userId = call.argument("userId");
                    Boolean startCameraImmediately = call.argument("startCameraImmediately");
                    if (startCameraImmediately == null)
                        startCameraImmediately = true;
                    if (userId == null)
                        userId = 0;

                    boolean startResult = NosmaiAgoraBridge.INSTANCE.startCustomCamera(
                            context, startAppId, token, channelId, userId, startCameraImmediately);
                    result.success(startResult);
                    break;

                case "stopCustomCamera":
                    boolean stopResult = NosmaiAgoraBridge.INSTANCE.stopCustomCamera();
                    result.success(stopResult);
                    break;

                case "teardownStreaming":
                    NosmaiAgoraBridge.INSTANCE.teardownStreaming();
                    result.success(true);
                    break;

                // Agora Controls
                case "enableVideo":
                    boolean enableVideoResult = NosmaiAgoraBridge.INSTANCE.enableVideo();
                    result.success(enableVideoResult);
                    break;

                case "enableLocalVideo":
                    Boolean enabled = call.argument("enabled");
                    boolean enableLocalVideoResult = NosmaiAgoraBridge.INSTANCE
                            .enableLocalVideo(enabled != null ? enabled : false);
                    result.success(enableLocalVideoResult);
                    break;

                case "startPreview":
                    boolean startPreviewResult = NosmaiAgoraBridge.INSTANCE.startPreview();
                    result.success(startPreviewResult);
                    break;

                case "stopPreview":
                    boolean stopPreviewResult = NosmaiAgoraBridge.INSTANCE.stopPreview();
                    result.success(stopPreviewResult);
                    break;

                case "setClientRole":
                    Integer role = call.argument("role");
                    boolean setClientRoleResult = NosmaiAgoraBridge.INSTANCE.setClientRole(role != null ? role : 1);
                    result.success(setClientRoleResult);
                    break;

                case "joinChannel":
                    String joinToken = call.argument("token");
                    String joinChannelId = call.argument("channelId");
                    Integer joinUserId = call.argument("userId");
                    boolean joinResult = NosmaiAgoraBridge.INSTANCE.joinChannel(
                            joinToken, joinChannelId, joinUserId != null ? joinUserId : 0);
                    result.success(joinResult);
                    break;

                case "leaveChannel":
                    boolean leaveResult = NosmaiAgoraBridge.INSTANCE.leaveChannel();
                    result.success(leaveResult);
                    break;

                // Beauty Filters
                case "applyBrightness":
                    Double brightness = call.argument("brightness");
                    boolean brightnessResult = NosmaiAgoraBridge.INSTANCE.applyBrightness(
                            brightness != null ? brightness.floatValue() : 0.0f);
                    result.success(brightnessResult);
                    break;

                case "applySkinSmoothing":
                    Double skinSmoothing = call.argument("level");
                    boolean skinSmoothingResult = NosmaiAgoraBridge.INSTANCE.applySkinSmoothing(
                            skinSmoothing != null ? skinSmoothing.floatValue() : 0.0f);
                    result.success(skinSmoothingResult);
                    break;

                case "applySkinWhitening":
                    Double skinWhitening = call.argument("level");
                    boolean skinWhiteningResult = NosmaiAgoraBridge.INSTANCE.applySkinWhitening(
                            skinWhitening != null ? skinWhitening.floatValue() : 0.0f);
                    result.success(skinWhiteningResult);
                    break;

                case "applyFaceSlimming":
                    Double faceSlimming = call.argument("level");
                    boolean faceSlimmingResult = NosmaiAgoraBridge.INSTANCE.applyFaceSlimming(
                            faceSlimming != null ? faceSlimming.floatValue() : 0.0f);
                    result.success(faceSlimmingResult);
                    break;

                case "applyEyeEnlargement":
                    Double eyeEnlargement = call.argument("level");
                    boolean eyeEnlargementResult = NosmaiAgoraBridge.INSTANCE.applyEyeEnlargement(
                            eyeEnlargement != null ? eyeEnlargement.floatValue() : 0.0f);
                    result.success(eyeEnlargementResult);
                    break;

                case "applyNoseSize":
                    Double noseSize = call.argument("level");
                    boolean noseSizeResult = NosmaiAgoraBridge.INSTANCE.applyNoseSize(
                            noseSize != null ? noseSize.floatValue() : 0.0f);
                    result.success(noseSizeResult);
                    break;

                case "applyContrast":
                    Double contrast = call.argument("contrast");
                    boolean contrastResult = NosmaiAgoraBridge.INSTANCE.applyContrast(
                            contrast != null ? contrast.floatValue() : 1.0f);
                    result.success(contrastResult);
                    break;

                case "applyHue":
                    Double hue = call.argument("hue");
                    boolean hueResult = NosmaiAgoraBridge.INSTANCE.applyHue(
                            hue != null ? hue.floatValue() : 0.0f);
                    result.success(hueResult);
                    break;

                case "applyRGB":
                    Double red = call.argument("red");
                    Double green = call.argument("green");
                    Double blue = call.argument("blue");
                    boolean rgbResult = NosmaiAgoraBridge.INSTANCE.applyRGB(
                            red != null ? red.floatValue() : 1.0f,
                            green != null ? green.floatValue() : 1.0f,
                            blue != null ? blue.floatValue() : 1.0f);
                    result.success(rgbResult);
                    break;

                case "applyLipstick":
                    Double lipstick = call.argument("intensity");
                    boolean lipstickResult = NosmaiAgoraBridge.INSTANCE.applyLipstick(
                            lipstick != null ? lipstick.floatValue() : 0.0f);
                    result.success(lipstickResult);
                    break;

                case "applyBlusher":
                    Double blusher = call.argument("intensity");
                    boolean blusherResult = NosmaiAgoraBridge.INSTANCE.applyBlusher(
                            blusher != null ? blusher.floatValue() : 0.0f);
                    result.success(blusherResult);
                    break;

                case "applyExposure":
                    Double exposure = call.argument("exposure");
                    boolean exposureResult = NosmaiAgoraBridge.INSTANCE.applyExposure(
                            exposure != null ? exposure.floatValue() : 0.0f);
                    result.success(exposureResult);
                    break;

                case "applySaturation":
                    Double saturation = call.argument("saturation");
                    boolean saturationResult = NosmaiAgoraBridge.INSTANCE.applySaturation(
                            saturation != null ? saturation.floatValue() : 1.0f);
                    result.success(saturationResult);
                    break;

                case "applySharpen":
                    Double sharpen = call.argument("sharpen");
                    boolean sharpenResult = NosmaiAgoraBridge.INSTANCE.applySharpen(
                            sharpen != null ? sharpen.floatValue() : 0.0f);
                    result.success(sharpenResult);
                    break;

                case "applyWhiteBalance":
                    Double temperatureK = call.argument("temperatureK");
                    Double tint = call.argument("tint");
                    boolean whiteBalanceResult = NosmaiAgoraBridge.INSTANCE.applyWhiteBalance(
                            temperatureK != null ? temperatureK.floatValue() : 5000.0f,
                            tint != null ? tint.floatValue() : 0.0f);
                    result.success(whiteBalanceResult);
                    break;

                case "setGrayscaleEnabled":
                    Boolean grayscaleEnabled = call.argument("enabled");
                    boolean grayscaleResult = NosmaiAgoraBridge.INSTANCE.setGrayscaleEnabled(
                            grayscaleEnabled != null ? grayscaleEnabled : false);
                    result.success(grayscaleResult);
                    break;

                case "removeAllFilters":
                    boolean removeFiltersResult = NosmaiAgoraBridge.INSTANCE.removeAllFilters();
                    result.success(removeFiltersResult);
                    break;

                case "applyMakeupBlendLevel":
                    String filterName = call.argument("filterName");
                    Double level = call.argument("level");
                    boolean makeupResult = NosmaiAgoraBridge.INSTANCE.applyMakeupBlendLevel(
                            filterName != null ? filterName : "",
                            level != null ? level.floatValue() : 0.0f);
                    result.success(makeupResult);
                    break;

                // Status and Info
                case "getCurrentFilterStates":
                    Map<String, Float> filterStates = NosmaiAgoraBridge.INSTANCE.getCurrentFilterStates();
                    Map<String, Object> convertedStates = new HashMap<>();
                    for (Map.Entry<String, Float> entry : filterStates.entrySet()) {
                        convertedStates.put(entry.getKey(), entry.getValue().doubleValue());
                    }
                    result.success(convertedStates);
                    break;

                case "hasActiveFilters":
                    boolean hasActiveFilters = NosmaiAgoraBridge.INSTANCE.hasActiveFilters();
                    result.success(hasActiveFilters);
                    break;

                case "getFlutterEngineInfo":
                    String engineInfo = NosmaiAgoraBridge.INSTANCE.getFlutterEngineInfo();
                    result.success(engineInfo);
                    break;

                // Filter and effect methods
                case "getLocalFilters":
                    handleGetLocalFilters(result);
                    break;

                case "getCloudFilters":
                    handleGetCloudFilters(result);
                    break;

                case "getFilters":
                    handleGetFilters(result);
                    break;

                case "applyEffect":
                case "applyFilter":
                    String effectPath = call.argument("path");
                    handleApplyEffect(effectPath, result);
                    break;

                case "removeAllEffects":
                    try {
                        NosmaiEffects.removeEffect();
                        result.success(true);
                    } catch (Exception e) {
                        android.util.Log.e("NosmaiAgoraPlugin", "Failed to remove effects: " + e.getMessage());
                        result.success(false);
                    }
                    break;

                case "isCloudFilterEnabled":
                    handleIsCloudFilterEnabled(result);
                    break;

                case "downloadCloudFilter":
                    String filterId = call.argument("filterId");
                    handleDownloadCloudFilter(filterId, result);
                    break;

                // Camera Support
                case "startCameraPreview":
                    boolean startCameraResult = NosmaiAgoraBridge.INSTANCE.startCameraPreview(context);
                    result.success(startCameraResult);
                    break;

                case "stopCameraPreview":
                    boolean stopCameraResult = NosmaiAgoraBridge.INSTANCE.stopCameraPreview();
                    result.success(stopCameraResult);
                    break;

                case "switchCamera":
                    boolean switchResult = NosmaiAgoraBridge.INSTANCE.switchCamera();
                    result.success(switchResult);
                    break;

                case "setFlashMode":
                    String flashMode = call.argument("flashMode");
                    boolean flashResult = NosmaiAgoraBridge.INSTANCE.setFlashMode(
                            flashMode != null ? flashMode : "off");
                    result.success(flashResult);
                    break;

                case "setTorchMode":
                    String torchMode = call.argument("torchMode");
                    boolean torchResult = NosmaiAgoraBridge.INSTANCE.setTorchMode(
                            torchMode != null ? torchMode : "off");
                    result.success(torchResult);
                    break;

                // Missing Nosmai camera methods
                case "cleanup":
                    boolean cleanupResult = NosmaiAgoraBridge.INSTANCE.cleanup();
                    result.success(cleanupResult);
                    break;

                case "startRecording":
                    boolean startRecResult = NosmaiAgoraBridge.INSTANCE.startRecording();
                    result.success(startRecResult);
                    break;

                case "stopRecording":
                    Map<String, Object> stopRecResult = NosmaiAgoraBridge.INSTANCE.stopRecording();
                    result.success(stopRecResult);
                    break;

                case "capturePhoto":
                    Map<String, Object> photoResult = NosmaiAgoraBridge.INSTANCE.capturePhoto();
                    result.success(photoResult);
                    break;

                case "saveImageToGallery":
                    byte[] imageData = call.argument("imageData");
                    String imageName = call.argument("name");
                    Map<String, Object> imageSaveResult = NosmaiAgoraBridge.INSTANCE.saveImageToGallery(
                            imageData != null ? imageData : new byte[0],
                            imageName != null ? imageName : "nosmai_image");
                    result.success(imageSaveResult);
                    break;

                case "saveVideoToGallery":
                    String videoPath = call.argument("videoPath");
                    String videoName = call.argument("name");
                    Map<String, Object> videoSaveResult = NosmaiAgoraBridge.INSTANCE.saveVideoToGallery(
                            videoPath != null ? videoPath : "",
                            videoName != null ? videoName : "nosmai_video");
                    result.success(videoSaveResult);
                    break;

                case "adjustHSB":
                    Double hsbHue = call.argument("hue");
                    Double hsbSaturation = call.argument("saturation");
                    Double hsbBrightness = call.argument("brightness");
                    boolean hsbResult = NosmaiAgoraBridge.INSTANCE.adjustHSB(
                            hsbHue != null ? hsbHue : 0.0,
                            hsbSaturation != null ? hsbSaturation : 1.0,
                            hsbBrightness != null ? hsbBrightness : 0.0);
                    result.success(hsbResult);
                    break;

                case "resetHSBFilter":
                    boolean resetHsbResult = NosmaiAgoraBridge.INSTANCE.resetHSBFilter();
                    result.success(resetHsbResult);
                    break;

                case "isBeautyFilterEnabled":
                    boolean beautyEnabled = NosmaiAgoraBridge.INSTANCE.isBeautyFilterEnabled();
                    result.success(beautyEnabled);
                    break;

                case "hasFlash":
                    boolean flashCapability = NosmaiAgoraBridge.INSTANCE.hasFlash();
                    result.success(flashCapability);
                    break;

                case "hasTorch":
                    boolean torchCapability = NosmaiAgoraBridge.INSTANCE.hasTorch();
                    result.success(torchCapability);
                    break;

                case "getFlashMode":
                    String currentFlashMode = NosmaiAgoraBridge.INSTANCE.getFlashMode();
                    result.success(currentFlashMode);
                    break;

                case "getTorchMode":
                    String currentTorchMode = NosmaiAgoraBridge.INSTANCE.getTorchMode();
                    result.success(currentTorchMode);
                    break;

                case "configureCamera":
                    String position = call.argument("position");
                    String sessionPreset = call.argument("sessionPreset");
                    boolean configureCameraResult = NosmaiAgoraBridge.INSTANCE.configureCamera(
                            position != null ? position : "front",
                            sessionPreset != null ? sessionPreset : "high");
                    result.success(configureCameraResult);
                    break;

                case "reinitializePreview":
                    boolean reinitializeResult = NosmaiAgoraBridge.INSTANCE.reinitializePreview();
                    result.success(reinitializeResult);
                    break;

                case "detachCameraView":
                    boolean detachResult = NosmaiAgoraBridge.INSTANCE.detachCameraView();
                    result.success(detachResult);
                    break;

                default:
                    result.notImplemented();
                    break;
            }
        } catch (Exception e) {
            result.error("NOSMAI_AGORA_ERROR", e.getMessage(), e.getStackTrace());
        }
    }

    // ============== FILTER IMPLEMENTATION METHODS ==============

    private void handleGetLocalFilters(Result result) {
        try {
            // Scan for .nosmai files in flutter assets
            List<Map<String, Object>> filters = new ArrayList<>();
            java.util.Set<String> seenFilters = new java.util.HashSet<>(); // Deduplication

            // Try to read AssetManifest.json to find filter assets
            try {
                String manifestJson = readAssetText("flutter_assets/AssetManifest.json");
                if (manifestJson != null) {
                    // Parse JSON manually (basic JSON parsing)
                    String[] lines = manifestJson.split("\"");
                    for (String line : lines) {
                        if (line.contains("assets/filters/") && line.endsWith(".nosmai")) {
                            String assetPath = line;
                            String name = extractFilterName(assetPath);

                            // Skip duplicates
                            if (seenFilters.contains(name)) {
                                continue;
                            }
                            seenFilters.add(name);

                            String displayName = toTitleCase(name);

                            // Try to get file size from asset
                            int fileSize = 0;
                            try {
                                java.io.InputStream inputStream = context.getAssets().open(assetPath);
                                fileSize = inputStream.available();
                                inputStream.close();
                            } catch (Exception e) {
                                // Use 0 if cannot determine size
                            }

                            Map<String, Object> filterMap = new HashMap<>();
                            filterMap.put("id", name);
                            filterMap.put("name", name);
                            filterMap.put("displayName", displayName);
                            filterMap.put("description", "Local filter");
                            filterMap.put("path", assetPath);
                            filterMap.put("fileSize", fileSize);
                            filterMap.put("type", "local");
                            filterMap.put("filterType", "effect");
                            filterMap.put("isDownloaded", true);
                            filterMap.put("isFree", true);
                            filterMap.put("isBuiltIn", true);

                            filters.add(filterMap);
                        }
                    }
                }
            } catch (Exception e) {
                // If manifest reading fails, return empty list
                android.util.Log.w("NosmaiAgoraPlugin", "Failed to read AssetManifest.json: " + e.getMessage());
            }

            android.util.Log.d("NosmaiAgoraPlugin", "Found " + filters.size() + " unique local filters");
            result.success(filters);
        } catch (Exception e) {
            result.error("LOCAL_FILTERS_ERROR", e.getMessage(), null);
        }
    }

    private void handleGetCloudFilters(Result result) {
        try {
            List<Map<String, Object>> filters = new ArrayList<>();

            // Try to use actual Nosmai Cloud SDK if available
            try {
                // TODO: Implement actual cloud filter loading when Nosmai Cloud SDK is
                // integrated
                // com.example.example.api.NosmaiCloud.list();
                android.util.Log.i("NosmaiAgoraPlugin",
                        "Cloud filters not available - Nosmai Cloud SDK not integrated");
            } catch (Exception e) {
                android.util.Log.w("NosmaiAgoraPlugin", "Failed to load cloud filters: " + e.getMessage());
            }

            result.success(filters);
        } catch (Exception e) {
            result.error("CLOUD_FILTERS_ERROR", e.getMessage(), null);
        }
    }

    private void handleGetFilters(Result result) {
        try {
            List<Map<String, Object>> allFilters = new ArrayList<>();
            final Result finalResult = result; // Final reference to outer result

            // Get local filters from assets
            handleGetLocalFilters(new Result() {
                @Override
                public void success(Object localResult) {
                    if (localResult instanceof List) {
                        allFilters.addAll((List<Map<String, Object>>) localResult);
                    }

                    // Try to get cloud filters too
                    handleGetCloudFilters(new Result() {
                        @Override
                        public void success(Object cloudResult) {
                            if (cloudResult instanceof List) {
                                allFilters.addAll((List<Map<String, Object>>) cloudResult);
                            }
                            finalResult.success(allFilters);
                        }

                        @Override
                        public void error(String errorCode, String errorMessage, Object errorDetails) {
                            // Ignore cloud filter errors, just return local filters
                            finalResult.success(allFilters);
                        }

                        @Override
                        public void notImplemented() {
                            finalResult.success(allFilters);
                        }
                    });
                }

                @Override
                public void error(String errorCode, String errorMessage, Object errorDetails) {
                    finalResult.error(errorCode, errorMessage, errorDetails);
                }

                @Override
                public void notImplemented() {
                    finalResult.notImplemented();
                }
            });

        } catch (Exception e) {
            result.error("GET_FILTERS_ERROR", e.getMessage(), null);
        }
    }

    private void handleIsCloudFilterEnabled(Result result) {
        try {
            // For demo purposes, return true
            // In real implementation, this would check Nosmai Cloud SDK
            result.success(true);
        } catch (Exception e) {
            result.success(false);
        }
    }

    private void handleDownloadCloudFilter(String filterId, Result result) {
        try {
            Map<String, Object> downloadResult = new HashMap<>();
            downloadResult.put("success", true);
            downloadResult.put("path", "/demo/path/" + filterId + ".nosmai");
            result.success(downloadResult);
        } catch (Exception e) {
            Map<String, Object> errorResult = new HashMap<>();
            errorResult.put("success", false);
            errorResult.put("error", e.getMessage());
            result.success(errorResult);
        }
    }

    private void handleApplyEffect(String effectPath, Result result) {
        try {
            android.util.Log.d("NosmaiAgoraPlugin", "Attempting to apply effect: " + effectPath);

            // First, copy the asset to cache directory if it's an asset path
            String actualPath = effectPath;
            if (effectPath.startsWith("assets/")) {
                actualPath = copyAssetToCache(effectPath);
                if (actualPath == null) {
                    android.util.Log.e("NosmaiAgoraPlugin", "Failed to copy asset to cache: " + effectPath);
                    result.success(false);
                    return;
                }
                android.util.Log.d("NosmaiAgoraPlugin", "Asset copied to: " + actualPath);
            }

            try {
                NosmaiEffects.applyEffect(actualPath);
                android.util.Log.d("NosmaiAgoraPlugin", "Effect applied successfully via NosmaiEffects.applyEffect()");
                result.success(true);
            } catch (Exception e) {
                android.util.Log.e("NosmaiAgoraPlugin", "NosmaiEffects.applyEffect failed: " + e.getMessage());
                result.success(false);
            }

        } catch (Exception e) {
            android.util.Log.e("NosmaiAgoraPlugin", "Error in handleApplyEffect: " + e.getMessage());
            result.success(false);
        }
    }

    // ============== HELPER METHODS ==============

    private String readAssetText(String assetPath) {
        try {
            java.io.InputStream inputStream = context.getAssets().open(assetPath);
            java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(inputStream));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private String extractFilterName(String assetPath) {
        // Extract filename without extension from path like
        // "assets/filters/vintage.nosmai"
        String[] parts = assetPath.split("/");
        String filename = parts[parts.length - 1];
        return filename.replace(".nosmai", "");
    }

    private String toTitleCase(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        StringBuilder titleCase = new StringBuilder();
        boolean nextTitleCase = true;

        for (char c : input.toCharArray()) {
            if (Character.isSpaceChar(c) || c == '_' || c == '-') {
                nextTitleCase = true;
                titleCase.append(' ');
            } else if (nextTitleCase) {
                titleCase.append(Character.toTitleCase(c));
                nextTitleCase = false;
            } else {
                titleCase.append(Character.toLowerCase(c));
            }
        }

        return titleCase.toString();
    }

    private String copyAssetToCache(String assetPath) {
        try {
            // Create cache directory for Nosmai filters
            java.io.File cacheDir = new java.io.File(context.getCacheDir(), "NosmaiLocalFilters");
            if (!cacheDir.exists()) {
                cacheDir.mkdirs();
            }

            // Get filename from asset path
            String fileName = assetPath.substring(assetPath.lastIndexOf('/') + 1);
            java.io.File outFile = new java.io.File(cacheDir, fileName);

            // If file already exists and has content, return its path
            if (outFile.exists() && outFile.length() > 0) {
                android.util.Log.d("NosmaiAgoraPlugin", "Using cached file: " + outFile.getAbsolutePath());
                return outFile.getAbsolutePath();
            }

            // For Flutter assets, we need to use the proper lookup key
            // Flutter assets are stored in "flutter_assets/" subdirectory
            String flutterAssetPath = assetPath;
            if (!assetPath.startsWith("flutter_assets/")) {
                flutterAssetPath = "flutter_assets/" + assetPath;
            }

            java.io.InputStream inputStream = null;

            // Try different paths to find the asset
            String[] pathsToTry = {
                    flutterAssetPath,
                    assetPath,
                    "flutter_assets/" + assetPath,
                    assetPath.replace("assets/", "flutter_assets/assets/")
            };

            for (String path : pathsToTry) {
                try {
                    inputStream = context.getAssets().open(path);
                    android.util.Log.d("NosmaiAgoraPlugin", "Found asset at: " + path);
                    break;
                } catch (Exception e) {
                    // Try next path
                }
            }

            if (inputStream == null) {
                android.util.Log.e("NosmaiAgoraPlugin", "Could not find asset in any of the tried paths");
                return null;
            }

            // Copy asset to cache
            java.io.FileOutputStream outputStream = new java.io.FileOutputStream(outFile);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            android.util.Log.d("NosmaiAgoraPlugin", "Asset copied successfully: " + outFile.getAbsolutePath());
            return outFile.getAbsolutePath();

        } catch (Exception e) {
            android.util.Log.e("NosmaiAgoraPlugin", "Failed to copy asset to cache: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}