package io.agora.agora_rtc_ng

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class YuvPreviewRenderer : GLSurfaceView.Renderer {
    private var program = 0
    private var posLoc = 0
    private var uvLoc = 0
    private var ySamplerLoc = 0
    private var uSamplerLoc = 0
    private var vSamplerLoc = 0
    private var vbo = 0
    private var texY = 0
    private var texU = 0
    private var texV = 0

    @Volatile private var frameData: ByteArray? = null
    @Volatile private var frameW = 0
    @Volatile private var frameH = 0
    private val hasNewFrame = AtomicBoolean(false)

    fun submitFrame(i420: ByteArray, width: Int, height: Int) {
        frameData = i420
        frameW = width
        frameH = height
        hasNewFrame.set(true)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val vs = """
            attribute vec2 aPos;
            attribute vec2 aUV;
            varying vec2 vUV;
            void main(){
              vUV = aUV;
              gl_Position = vec4(aPos, 0.0, 1.0);
            }
        """
        val fs = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D texY;
            uniform sampler2D texU;
            uniform sampler2D texV;
            void main(){
              float y = texture2D(texY, vUV).r;
              float u = texture2D(texU, vUV).r - 0.5;
              float v = texture2D(texV, vUV).r - 0.5;
              float r = y + 1.402 * v;
              float g = y - 0.344136 * u - 0.714136 * v;
              float b = y + 1.772 * u;
              gl_FragColor = vec4(r, g, b, 1.0);
            }
        """
        program = buildProgram(vs, fs)
        posLoc = GLES20.glGetAttribLocation(program, "aPos")
        uvLoc = GLES20.glGetAttribLocation(program, "aUV")
        ySamplerLoc = GLES20.glGetUniformLocation(program, "texY")
        uSamplerLoc = GLES20.glGetUniformLocation(program, "texU")
        vSamplerLoc = GLES20.glGetUniformLocation(program, "texV")

        // Non-mirrored preview (same orientation as filters and remote)
        val data = floatArrayOf(
            -1f, -1f, 0f, 1f,
             1f, -1f, 1f, 1f,
            -1f,  1f, 0f, 0f,
             1f,  1f, 1f, 0f
        )
        val buffers = IntArray(1)
        GLES20.glGenBuffers(1, buffers, 0)
        vbo = buffers[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        val bb = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        bb.put(data).position(0)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.size * 4, bb, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)

        val texs = IntArray(3)
        GLES20.glGenTextures(3, texs, 0)
        texY = texs[0]; texU = texs[1]; texV = texs[2]
        initLumaTex(texY)
        initLumaTex(texU)
        initLumaTex(texV)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        val data = frameData ?: return
        val w = frameW
        val h = frameH
        if (!hasNewFrame.getAndSet(false)) {
            // still draw with last textures
        } else {
            val ySize = w * h
            val uvSize = ySize / 4
            val yBuf = ByteBuffer.wrap(data, 0, ySize)
            val uBuf = ByteBuffer.wrap(data, ySize, uvSize)
            val vBuf = ByteBuffer.wrap(data, ySize + uvSize, uvSize)

            uploadPlane(texY, w, h, yBuf)
            uploadPlane(texU, w / 2, h / 2, uBuf)
            uploadPlane(texV, w / 2, h / 2, vBuf)
        }

        GLES20.glUseProgram(program)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glEnableVertexAttribArray(posLoc)
        GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 16, 0)
        GLES20.glEnableVertexAttribArray(uvLoc)
        GLES20.glVertexAttribPointer(uvLoc, 2, GLES20.GL_FLOAT, false, 16, 8)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texY)
        GLES20.glUniform1i(ySamplerLoc, 0)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texU)
        GLES20.glUniform1i(uSamplerLoc, 1)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texV)
        GLES20.glUniform1i(vSamplerLoc, 2)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun initLumaTex(id: Int) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    private fun uploadPlane(id: Int, w: Int, h: Int, buf: ByteBuffer) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
        // Use GL_LUMINANCE for ES2 compatibility
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_LUMINANCE, w, h, 0, GLES20.GL_LUMINANCE, GLES20.GL_UNSIGNED_BYTE, buf)
    }

    private fun buildProgram(vsSrc: String, fsSrc: String): Int {
        fun compile(type: Int, src: String): Int {
            val sh = GLES20.glCreateShader(type)
            GLES20.glShaderSource(sh, src)
            GLES20.glCompileShader(sh)
            val status = IntArray(1)
            GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, status, 0)
            if (status[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(sh)
                GLES20.glDeleteShader(sh)
                throw RuntimeException("Shader compile failed: $log")
            }
            return sh
        }
        val vs = compile(GLES20.GL_VERTEX_SHADER, vsSrc)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fsSrc)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        val status = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(prog)
            GLES20.glDeleteProgram(prog)
            throw RuntimeException("Program link failed: $log")
        }
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        return prog
    }
}